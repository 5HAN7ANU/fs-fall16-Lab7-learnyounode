var fs = require('fs');
var buffer = fs.readFileSync(process.argv[2]);
var string = buffer.toString();
var newLinesArray = string.split('\n');
var newLines = newLinesArray.length - 1;
console.log(newLines);