var fs = require('fs');
var filePath = process.argv[2];

fs.readFile(filePath, function(err, data){
    if(err){
        console.log('error! ' + err);
    }

    var myString = data.toString();
    var newLinesArray = myString.split('\n');
    var newLines = newLinesArray.length - 1; 
    console.log(newLines);
});