var http = require('http');
var fs = require('fs');
var portNumber = Number(process.argv[2]);
console.log('Port Number: ' + portNumber);
console.log('process.argv: ' + process.argv);

var server = http.createServer(function (request, response){
    if(request == 'POST'){
        console.log('A POST request is made');
        var text = fs.createReadStream();

        request.on('data', function(data){
            text += data.toString();
        });

        request.on('end', function(){
            response.end(text.toUpperCase());
            text.pipe(response);
        });
    };
});

server.listen(portNumber);