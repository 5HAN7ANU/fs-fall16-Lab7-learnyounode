//console.log(process.argv);
var j = 0;
var sum = 0;
var arrayLength = (process.argv).length;

if(arrayLength > 2){
    for(var i = 2; i < arrayLength; i++){
        j = Number(process.argv[i]);
        sum = sum + j;
    }
}else{};

console.log(sum);