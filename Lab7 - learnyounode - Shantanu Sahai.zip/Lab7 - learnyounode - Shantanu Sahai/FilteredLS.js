var fs = require('fs');
var path = require('path');
var filePath = process.argv[2];
var fileExtension = '.' + process.argv[3];

fs.readdir(filePath, function(err, list){
    if(err){
        console.log('error! ' + err);
    }
    
    list.forEach(function(filename){
        var extension = path.extname(filename);
        if(extension === fileExtension){
            console.log(filename);
        }
    });
});