var http = require('http');
var fs = require('fs');
var url = require('url');
var portNumber = Number(process.argv[2]);
console.log('Port Number: ' + portNumber);
console.log('process.argv: ' + process.argv);

var server = http.createServer(function(request, response){

});
server.listen(portNumber);