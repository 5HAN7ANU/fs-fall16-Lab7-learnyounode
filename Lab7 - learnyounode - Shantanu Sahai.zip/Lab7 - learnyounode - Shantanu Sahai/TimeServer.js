var net = require('net');
var portNumber = Number(process.argv[2]);

var server = net.createServer(function (socket) {  
    var date = new Date();
    var year = String(date.getFullYear());
    var month = String(date.getMonth() + 1);
    if(month.length < 2){
        month = '0' + month;
    };

    var day = String(date.getDate());
    if(day.length < 2){
        day = '0' + day;
    };

    var hours = String(date.getHours());
    if(hours.length < 2){
        hours = '0' + hours;
    };

    var minutes = String(date.getMinutes());
    if(minutes.length < 2){
        minutes = '0' + minutes;
    }

    var finalString = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + '\n';

    socket.write(finalString);
    socket.end();
    console.log('finished writing the string and closed socket');
});  

server.listen(portNumber);